#!/bin/bash

hostname
