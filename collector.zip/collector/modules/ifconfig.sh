#!/bin/bash
ifconfig -a
