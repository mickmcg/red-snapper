#!/bin/bash

df -h
