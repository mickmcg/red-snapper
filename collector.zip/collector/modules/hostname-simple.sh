#!/bin/bash

hostname -s
